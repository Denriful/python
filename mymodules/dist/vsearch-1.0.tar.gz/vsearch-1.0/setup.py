#!/usr/bin/env python
from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Denriful',
    author_email='sobran68@mail.ru',
    url='med54.ru',
    py_modules=['vsearch']
)