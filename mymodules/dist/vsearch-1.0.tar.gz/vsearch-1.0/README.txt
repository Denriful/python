This module Return sets of letters in phrase

Type help(search4letters) for find more.